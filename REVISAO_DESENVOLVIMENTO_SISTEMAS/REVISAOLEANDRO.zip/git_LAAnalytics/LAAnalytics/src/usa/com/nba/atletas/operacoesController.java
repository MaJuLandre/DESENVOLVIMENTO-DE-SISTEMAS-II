package usa.com.nba.atletas;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitPane;
import javafx.stage.Stage;

public class operacoesController {
	
	@FXML
    private SplitPane splitPane;

	@FXML
	private MenuItem mniFechar;
	
	@FXML
	private Stage palco;
	
	@FXML
	private void fecharTela(ActionEvent event) {
		palco = (Stage) mniFechar.getParentPopup().getOwnerWindow();
		palco.close();
	}
    
	
}
