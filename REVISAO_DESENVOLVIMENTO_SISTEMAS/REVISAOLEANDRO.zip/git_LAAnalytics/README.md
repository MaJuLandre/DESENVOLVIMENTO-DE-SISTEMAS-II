# LAAnalytics
Exercício em aula
